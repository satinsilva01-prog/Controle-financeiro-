MINHAS FINANÇAS — projeto APK

Este projeto empacota a versão aprovada do index.html dentro de um aplicativo Android.

Como usar no GitHub:
1. Envie todo o conteúdo desta pasta para um repositório.
2. No GitHub, abra Actions.
3. Execute "Build MINHAS FINANÇAS APK".
4. Ao terminar, abra a execução e baixe o artefato "MINHAS-FINANCAS-APK".

O APK usa o arquivo local app/src/main/assets/index.html e o ícone próprio em res/mipmap-*.
