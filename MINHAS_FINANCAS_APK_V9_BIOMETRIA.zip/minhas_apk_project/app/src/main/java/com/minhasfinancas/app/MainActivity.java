package com.minhasfinancas.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.net.Uri;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private boolean biometricStarted = false;
    private android.hardware.biometrics.BiometricPrompt activePrompt;
    private CancellationSignal activeCancellation;
    private boolean enableMode = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.addJavascriptInterface(new BiometricBridge(), "AndroidBiometric");
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!biometricStarted) {
                    biometricStarted = true;
                    webView.postDelayed(() -> startBiometricIfReady(), 700);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = params.createIntent();
                try { startActivityForResult(i, FILE_CHOOSER); } catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startBiometricIfReady() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return;

        // Só oferece biometria depois que a senha do MINHAS FINANÇAS já existe.
        webView.evaluateJavascript(
                "(function(){try{return (localStorage.getItem('MF_APP_ACCESS_PASSWORD_V1') ? '1' : '0') + ':' + (localStorage.getItem('MF_BIOMETRIC_ENABLED_V1') === '1' ? '1' : '0');}catch(e){return '0:0';}})()",
                value -> {
                    if (!("\"1:1\"".equals(value) || "1:1".equals(value))) return;
                    enableMode = false;
                    showBiometricPrompt();
                });
    }

    private void showBiometricPrompt() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (enableMode) { enableMode = false; webView.evaluateJavascript("window.MF_biometricEnableResult(false)", null); }
            return;
        }

        BiometricManager manager = (BiometricManager) getSystemService(BIOMETRIC_SERVICE);
        if (manager == null) {
            if (enableMode) { enableMode = false; webView.evaluateJavascript("window.MF_biometricEnableResult(false)", null); }
            return;
        }

        int result = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (result != BiometricManager.BIOMETRIC_SUCCESS) {
            if (enableMode) { enableMode = false; webView.evaluateJavascript("window.MF_biometricEnableResult(false)", null); }
            return;
        }

        Executor executor = getMainExecutor();
        BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this)
                .setTitle("MINHAS FINANÇAS")
                .setSubtitle("Desbloquear aplicativo")
                .setDescription("Use sua digital para desbloquear o MINHAS FINANÇAS")
                .setNegativeButton("Usar senha", executor, (dialog, which) -> {
                    // A tela de senha do HTML continua disponível.
                });

        activePrompt = builder.build();
        activeCancellation = new CancellationSignal();
        activePrompt.authenticate(activeCancellation, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                if (enableMode) {
                    enableMode = false;
                    webView.evaluateJavascript("window.MF_biometricEnableResult(true)", null);
                } else {
                    unlockHtmlAfterBiometric();
                }
            }

            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                if (enableMode) {
                    enableMode = false;
                    webView.evaluateJavascript("window.MF_biometricEnableResult(false)", null);
                }
                // Falha/cancelamento mantém a tela de senha disponível.
            }
        });
    }

    private void unlockHtmlAfterBiometric() {
        webView.evaluateJavascript(
                "(function(){var g=document.getElementById('mfAuthGate');" +
                "if(g){g.style.display='none';}" +
                "document.body.classList.remove('mf-locked');" +
                "return true;})()", null);
    }


    private class BiometricBridge {
        @JavascriptInterface public void requestEnable() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    webView.evaluateJavascript("window.MF_biometricEnableResult(false)", null);
                    return;
                }
                enableMode = true;
                showBiometricPrompt();
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
