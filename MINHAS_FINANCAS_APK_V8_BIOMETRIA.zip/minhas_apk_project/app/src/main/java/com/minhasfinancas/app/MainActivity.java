package com.minhasfinancas.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;
    private boolean biometricStarted = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!biometricStarted) {
                    biometricStarted = true;
                    startBiometricIfReady();
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = params.createIntent();
                try { startActivityForResult(i, FILE_CHOOSER); } catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startBiometricIfReady() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return;

        // Only offer biometric login when the MINHAS FINANÇAS password has already been created.
        webView.evaluateJavascript("Boolean(localStorage.getItem('MF_APP_ACCESS_PASSWORD_V1'))", value -> {
            if (!"true".equals(value)) return;
            showBiometricPrompt();
        });
    }

    private void showBiometricPrompt() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return;

        BiometricManager manager = (BiometricManager) getSystemService(BIOMETRIC_SERVICE);
        if (manager == null) return;

        int result;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            result = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        } else {
            result = manager.canAuthenticate();
        }
        if (result != BiometricManager.BIOMETRIC_SUCCESS) return;

        Executor executor = getMainExecutor();
        BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this)
                .setTitle("MINHAS FINANÇAS")
                .setSubtitle("Desbloqueio por digital")
                .setDescription("Use sua digital para entrar no aplicativo")
                .setNegativeButton("Usar senha", executor, (dialog, which) -> {
                    // The normal HTML password screen remains visible.
                });

        BiometricPrompt prompt = builder.build();
        CancellationSignal cancellationSignal = new CancellationSignal();
        prompt.authenticate(cancellationSignal, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                unlockHtmlAfterBiometric();
            }

            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                // Keep the normal password screen available. No data is changed.
            }
        });
    }

    private void unlockHtmlAfterBiometric() {
        webView.evaluateJavascript(
                "(function(){var g=document.getElementById('mfAuthGate');" +
                "if(g){g.style.display='none';}" +
                "document.body.classList.remove('mf-locked');" +
                "return true;})()", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
